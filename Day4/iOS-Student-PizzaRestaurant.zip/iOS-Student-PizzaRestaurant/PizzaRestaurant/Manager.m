//
//  Manager.m
//  PizzaRestaurant
//
//  Created by Jeff Eom on 2016-07-01.
//  Copyright © 2016 Lighthouse Labs. All rights reserved.
//

#import "Manager.h"
#import "Kitchen.h"
#import "Pizza.h"


@implementation Manager

-(BOOL)kitchen:(Kitchen *)kitchen shouldMakePizzaOfSize:(SizeValue)size andToppings:(NSArray *)toppings {
    if (size <= 3 && toppings) {
        return true;
    } else {
        return false;
    }
}

-(BOOL)kitchenShouldUpgradeOrder:(Kitchen *)kitchen{
    if(YES){
        return [self kitchen:kitchen shouldMakePizzaOfSize:3 andToppings:@[]];
    }else{
        return false;
    }
}

-(void)kitchenDidMakePizza:(Pizza *)pizza{
    NSLog(@"Pizza has been made: %@ ", pizza);
}
@end
