//
//  Pizza.h
//  PizzaRestaurant
//
//  Created by Jeff Eom on 2016-06-30.
//  Copyright © 2016 Lighthouse Labs. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum{
    small,
    medium,
    large,
} SizeValue;

@interface Pizza : NSObject

@property (nonatomic, readonly) NSArray *toppings;
@property (nonatomic, readonly) SizeValue sizeValue;

- (SizeValue) pizzaSizeValue;
- (NSArray *) pizzaToppings;

- (instancetype)initWithSize:(SizeValue)size andToppings:(NSArray *)toppings;

@end
