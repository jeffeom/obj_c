//
//  Pizza.m
//  PizzaRestaurant
//
//  Created by Jeff Eom on 2016-06-30.
//  Copyright © 2016 Lighthouse Labs. All rights reserved.
//

#import "Pizza.h"

@implementation Pizza

- (instancetype)initWithSize:(SizeValue)sizeValue andToppings:(NSArray *)toppings
{
    self = [super init];
    if (self) {
        _sizeValue = sizeValue;
        _toppings = toppings;
    }
    return self;
}


- (SizeValue) pizzaSizeValue{
    return self.sizeValue;
}

- (NSArray *) pizzaToppings{
    return self.toppings;
}

@end
