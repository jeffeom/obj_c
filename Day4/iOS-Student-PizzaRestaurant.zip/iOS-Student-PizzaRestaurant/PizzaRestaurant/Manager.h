//
//  Manager.h
//  PizzaRestaurant
//
//  Created by Jeff Eom on 2016-07-01.
//  Copyright © 2016 Lighthouse Labs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KitchenDelegate.h"

@interface Manager : NSObject <KitchenDelegate>

@end
