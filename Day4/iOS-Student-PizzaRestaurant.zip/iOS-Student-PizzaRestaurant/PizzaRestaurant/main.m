//
//  main.m
//  PizzaRestaurant
//
//  Created by Steven Masuch on 2014-07-19.
//  Copyright (c) 2014 Lighthouse Labs. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "Kitchen.h"
#import "Pizza.h"
#import "Manager.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSLog(@"Please pick your pizza size and toppings:");
        
        Kitchen *restaurantKitchen = [Kitchen new];
        Manager *pizzaManager = [Manager new];
        
        while (TRUE) {
            // Loop forever
            
            NSLog(@"> ");
            char str[100];
            fgets (str, 100, stdin);
            
            NSString *inputString = [[NSString alloc] initWithUTF8String:str];
            inputString = [inputString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            
            NSLog(@"Input was %@", inputString);
            
            // Take the first word of the command as the size, and the rest as the toppings
            NSArray *commandWords = [inputString componentsSeparatedByString:@" "];
            
            // And then send some message to the kitchen...
//            Pizza *pizza1 = [[Pizza alloc] initWithSize:commandWords[0] andToppings:commandWords[1]];
            
            int size;
            
            if ([commandWords[0] isEqualToString:@"small"]) {
                size = 0;
            }else if([commandWords[0] isEqualToString:@"medium"]){
                size = 1;
            }else if([commandWords[0] isEqualToString:@"large"]){
                size = 2;
            }
            
            SizeValue sizeInString = size;
            
            NSMutableArray *orderedToppings = [[NSMutableArray alloc] init];
            for(int i = 1; i < [commandWords count]; i++){
                [orderedToppings addObject:commandWords[i]];
            }
            
            [restaurantKitchen makePizzaWithSize:sizeInString toppings:orderedToppings];
            
            if ([pizzaManager kitchen:restaurantKitchen shouldMakePizzaOfSize:sizeInString andToppings:orderedToppings]){
                Pizza *pizza = [restaurantKitchen makePizzaWithSize:sizeInString toppings:orderedToppings];
                [pizzaManager kitchenDidMakePizza:pizza];
            }
            
      
//            if([restaurantKitchen kitchen:restaurantKitchen shouldMakePizzaOfSize:sizeInString andToppings:orderedToppings]){
//                Pizza *pizza = [restaurantKitchen makePizzaWithSize:sizeInString toppings:orderedToppings];
//                [restaurantKitchen kitchenDidMakePizza:pizza];
//            }else{
//                NSLog(@"No pizza for you");
//            }
        }

    }
    return 0;
}

