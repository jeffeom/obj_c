//
//  Kitchen.m
//  PizzaRestaurant
//
//  Created by Steven Masuch on 2014-07-19.
//  Copyright (c) 2014 Lighthouse Labs. All rights reserved.
//

#import "Kitchen.h"
#import "Pizza.h"
#import "Manager.h"


@implementation Kitchen

- (Pizza *)makePizzaWithSize:(SizeValue)size toppings:(NSArray *)toppings
{
    Manager *manager = [Manager new];
    //    self.delegate = self;
     self.delegate = manager;
    if([manager kitchen:self shouldMakePizzaOfSize:size andToppings:toppings]){
        return [[Pizza alloc]initWithSize:size andToppings:toppings];
    }else{
        NSLog(@"No Pizza for YOU! Please enter the proper input for sizes and toppings");
        return nil;
    }
    
    
    //should make pizza of size
    //should upgrade order
}

//-(BOOL)kitchen:(Kitchen *)kitchen shouldMakePizzaOfSize:(SizeValue)size andToppings:(NSArray *)toppings {
//    if (size <= 3 && toppings) {
//        return true;
//    } else {
//        return false;
//    }
//}
//
//-(BOOL)kitchenShouldUpgradeOrder:(Kitchen *)kitchen{
//    if(YES){
//        return [kitchen kitchen:kitchen shouldMakePizzaOfSize:3 andToppings:@[]];
//    }else{
//        NSLog(@"No pizza upgrade for you!");
//    }
//}
//
//-(void)kitchenDidMakePizza:(Pizza *)pizza{
//    NSLog(@"Pizza has been made: %@ ", pizza);
//}

@end
