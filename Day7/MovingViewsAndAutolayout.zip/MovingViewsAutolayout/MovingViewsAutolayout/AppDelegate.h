//
//  AppDelegate.h
//  MovingViewsAutolayout
//
//  Created by Cory Alder on 2016-07-05.
//  Copyright © 2016 Davander Mobile Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

