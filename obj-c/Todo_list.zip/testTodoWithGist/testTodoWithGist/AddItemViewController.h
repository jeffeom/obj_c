//
//  AddItemViewController.h
//  testTodoWithGist
//
//  Created by Jeff Eom on 2016-06-07.
//  Copyright © 2016 Jeff Eom. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol AddItemViewControllerDelegate <NSObject>

- (void)didSaveNewTodo: (NSString *)todoText;

@end


@interface AddItemViewController : UIViewController

@property (nonatomic, strong) id <AddItemViewControllerDelegate> delegate;

- (IBAction)save:(id)sender;

- (IBAction)cancel:(id)sender;

@end
