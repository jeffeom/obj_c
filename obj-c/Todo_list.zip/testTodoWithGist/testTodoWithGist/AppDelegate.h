//
//  AppDelegate.h
//  testTodoWithGist
//
//  Created by Jeff Eom on 2016-06-05.
//  Copyright © 2016 Jeff Eom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

