//
//  ListTableViewCell.h
//  testTodoWithGist
//
//  Created by Jeff Eom on 2016-06-05.
//  Copyright © 2016 Jeff Eom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ListTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@end
