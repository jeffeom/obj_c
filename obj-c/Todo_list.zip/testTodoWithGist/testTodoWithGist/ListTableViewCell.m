//
//  ListTableViewCell.m
//  testTodoWithGist
//
//  Created by Jeff Eom on 2016-06-05.
//  Copyright © 2016 Jeff Eom. All rights reserved.
//

#import "ListTableViewCell.h"

@implementation ListTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
